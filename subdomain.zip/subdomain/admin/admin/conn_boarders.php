<?php
$conn = mysql_connect("localhost","root","") or die ("Unable to connect");



mysql_Select_db('boarders',$conn) or die ("cannot select DB");
				  
					  
 ?>