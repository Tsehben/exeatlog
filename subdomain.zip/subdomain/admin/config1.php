<?php
$conn= mysqli_connect("localhost","root","","login") or die ("Unable to connect");
$conn1 = mysqli_connect("localhost","root","","boarders") or die ("Unable to connect");
$conn2 = mysqli_connect("localhost","root","","exeats") or die ("Unable to connect");
$conn3 = mysqli_connect("localhost","root","","security") or die ("Unable to connect");
$conn4 = mysqli_connect("localhost","root","","register") or die ("Unable to connect");
 ?>