<?php

$conn1= mysql_connect("presec.exeatlog.com","master","exeatdb@2019" ) or die ("Unable to connect");


mysql_Select_db('exeats',$conn1) or die ("cannot select DB");
				  
					  
 ?>