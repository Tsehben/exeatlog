<?php
include ('config/config.php');
session_start();
$code= mt_rand(1,10000);
$to = $_SESSION['email'];
$subject = "Account Verification";
$txt = "Hello,".$_SESSION['username']."\n\nThis is your account verification code\n<b>".$code."</b>\n Use this code to change your password.\n\nThank you.  ";
$headers = "Exeatlog" . "\r\n";

mail($to,$subject,$txt,$headers);

if(isset($_POST['code']) && isset($_POST['password']) &&isset($_POST['cpassword']) && $_POST['code'] ==$code){
$password =$_POST['password'];
$cpassword =$_POST['cpassword'];
if($cpassword == $password){
	$query ="UPDATE housemasters SET password='$password' WHERE username ='$username' ";
	$query_run =mysqli_query($conn,$query);
	
	if ($query_run){
		
		
	}
	else{
		$query ="UPDATE register SET password='$password' WHERE username ='$username' ";
	$query_run =mysqli_query($conn3,$query);
		
		if ($query_run){
		
		
	}
	
	}
}	
}

?>