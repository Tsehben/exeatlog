<html>

<form action="sms.php" method="POST">
Phone Number:
<input type="text" name="number"/></br>
<textarea name ="msg">


</textarea>
</br>
<input type="submit" name="send"/>
</form>
</html>







<?php

include './vendor/autoload.php';
use Twilio\Rest\Client;
if (isset($_POST['number']) && isset($_POST['msg'])){
// Your Account SID and Auth Token from twilio.com/console
$account_sid = 'AC59160a752009e2a440a54fa5af2cba7c';
$auth_token = '026550ef0a74affd9300533391e23c1f';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_ACCOUNT_SID"]

// A Twilio number you own with SMS capabilities
$twilio_number = "+18649009868";

$client = new Client($account_sid, $auth_token);
$sent =$client->messages->create(
    // Where to send a text message (your cell phone?)
    $_POST['number'],
    array(
	
        'from' => $twilio_number,
        'body' => $_POST['msg'] 
		)
);

if ($sent ->sid){
	
		$account_sid = 'AC59160a752009e2a440a54fa5af2cba7c';
$auth_token = '026550ef0a74affd9300533391e23c1f';
// In production, these should be environment variables. E.g.:
// $auth_token = $_ENV["TWILIO_ACCOUNT_SID"]

// A Twilio number you own with SMS capabilities
$twilio_number = "+18649009868";

$client = new Client($account_sid, $auth_token);
$sent =$client->messages->create(
    // Where to send a text message (your cell phone?)
    '+233559292657',
    array(
	
        'from' => $twilio_number,
        'body' => $_POST['msg'] 
		)
);


	if ($sent-> sid){
	    echo 'Message has been sent'; 
	    
	}
	else{
	    
	    echo 'Error';
	}

	
}
else{
	    
	    echo 'Error';
	}


}
?>